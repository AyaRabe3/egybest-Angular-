import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-series',
  templateUrl: './edit-series.component.html',
  styleUrls: ['./edit-series.component.scss']
})
export class EditSeriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
